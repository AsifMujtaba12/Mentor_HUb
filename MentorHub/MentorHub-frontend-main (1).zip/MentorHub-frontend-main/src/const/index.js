export const USER_STORE_PERSIST = "Xc8vj8*>T6g7";
export const TOKEN = "7g6T>*8jv8cX";
